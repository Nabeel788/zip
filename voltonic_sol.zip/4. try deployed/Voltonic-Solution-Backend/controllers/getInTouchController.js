import Model from "../models/getInTouchModel.js";

// add a new item
export const addItem = async (req, res) => {
  try {
    const { heading, description, phone, email } = req.body;

    let item = new Model({
      heading,
      description,
      phone,
      email,
    });

    await item.save();

    res.status(201).send({
      success: true,
      message: "item added successfully",
      item,
    });
  } catch (error) {
    console.log(error);
    res.status(500).json({ error: "Failed to add item" });
  }
};

// get single item
export const GetSingleItem = async (req, res) => {
  try {
    const { id } = req.params;
    const item = await Model.findById(id);
    res.json(item);
  } catch (error) {
    res.status(500).json({ error: "failed to get item" });
  }
};

// get all items
export const getAllItems = async (req, res) => {
  try {
    const items = await Model.find();
    res.json(items);
  } catch (error) {
    res.status(500).json({ error: "Failed to fetch items" });
  }
};

// update a item
export const updateItem = async (req, res) => {
  try {
    const { id } = req.params;
    const { heading, description, phone, email } = req.body;

    const updatedItem = await Model.findByIdAndUpdate(
      id,
      {
        heading,
        description,
        phone,
        email,
      },
      { new: true } //"new" option set to true to return the updated item directly
    );

    if (updatedItem) {
      res.json(updatedItem);
    } else {
      res.status(404).json({ error: "Item not found" });
    }
  } catch (error) {
    res.status(500).json({ error: "Failed to update item" });
  }
};

// delete a item
export const deleteItem = async (req, res) => {
  try {
    const { id } = req.params;
    const deletedItem = await Model.findByIdAndRemove(id);

    if (deletedItem) {
      res.json(deletedItem);
    } else {
      res.status(404).json({ error: "Item not found" });
    }
  } catch (error) {
    res.status(500).json({ error: "failed to delete item" });
  }
};
