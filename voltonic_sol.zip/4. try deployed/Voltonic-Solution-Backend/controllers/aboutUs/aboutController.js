import {
  addItem,
  getAllItems,
  updateItem,
  deleteItem,
  GetSingleItem,
} from "../../BLL/aboutUs/aboutBanner/aboutBannerCRUD.js";

export const aboutBannerMethods = {
  addItem,
  getAllItems,
  updateItem,
  deleteItem,
  GetSingleItem,
};

export const aboutHeaderMethods = {
  addItem,
  getAllItems,
  updateItem,
  deleteItem,
  GetSingleItem,
};
