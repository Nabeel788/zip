import express from "express";
import {
  addItem,
  getAllItems,
  updateItem,
  deleteItem,
  GetSingleItem,
} from "../../controllers/contactUs/contactFooterCountryController.js";

const router = express.Router();

// route for adding a new item
router.post("/add", addItem);

// router for get single item
router.get("/get-single-item/:id", GetSingleItem);

// router for getting all item
router.get("/show-all", getAllItems);

// route for updating a item
// patch method is standard RESTful API convention for updating resources, however post method can also works correctly
router.post("/update/:id", updateItem);

// route for deleting a item
router.delete("/delete/:id", deleteItem);

export default router;
