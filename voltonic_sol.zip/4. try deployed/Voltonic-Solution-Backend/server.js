import express from "express";
import dotenv from "dotenv";
import colors from "colors";
import dbConnection from "./config/db.js";
import cors from "cors";
import morgan from "morgan";
import cookieParser from "cookie-parser";

import aboutBannerRoute from "./routes/aboutUs/aboutBannerRoute.js";
import aboutHeaderRoute from "./routes/aboutUs/aboutHeaderRoute.js";
import aboutFeaturesRoute from "./routes/aboutUs/aboutFeaturesRoute.js";
import aboutHistoryHeaderRoute from "./routes/aboutUs/aboutHistoryHeaderRoute.js";
import aboutHistoryWorkRoute from "./routes/aboutUs/aboutHistoryWorkRoute.js";
import aboutChooseHeaderRoute from "./routes/aboutUs/aboutHistoryHeaderRoute.js";
import aboutChooseServiceRoute from "./routes/aboutUs/aboutChooseServiceRoute.js";
import getInTouchRoute from "./routes/getInTouchRoute.js";
import homeSliderRoute from "./routes/home/homeSliderRoute.js";
import homeHeaderRoute from "./routes/home/homeHeaderRoute.js";
import homeProjectsHeaderRoute from "./routes/home/homeProjectsHeaderRoute.js";
import homeHeaderPointRoute from "./routes/home/homeHeaderPointRoute.js";
import homeServiceRoute from "./routes/home/homeServiceRoute.js";
import homeBrandRoute from "./routes/home/homeBrandRoute.js";
import projectBannerRoute from "./routes/project/projectBannerRoute.js";
import projectBottomRoute from "./routes/project/projectBottomRoute.js";
import projectRoute from "./routes/project/projectRoute.js";
import contactBannerRoute from "./routes/contactUs/contactBannerRoute.js";
import contactHeaderRoute from "./routes/contactUs/contactHeaderRoute.js";
import contactFormRoute from "./routes/contactUs/contactFormRoute.js";
import contactFooterRoute from "./routes/contactUs/contactFooterRoute.js";
import contactFooterCompanyRoute from "./routes/contactUs/contactFooterCompanyRoute.js";
import contactFooterCountryRoute from "./routes/contactUs/contactFooterCountryRoute.js";
import logoRoute from "./routes/logoRoute.js";
import serviceBannerRoute from "./routes/service/serviceBannerRoute.js";
import serviceRoute from "./routes/service/serviceRoute.js";
import serviceHeaderRoute from "./routes/service/serviceHeaderRoute.js";
import supportRoute from "./routes/supportRoute.js";
import subscribeRoute from "./routes/subscribeRoute.js";
import authRoute from "./routes/AuthRoute.js";
import chooseUsHeaderRoute from "./routes/chooseUs/chooseUsHeaderRoute.js";
import chooseUsProgressRoute from "./routes/chooseUs/chooseUsProgressRoute.js";
import chooseUsFactRoute from "./routes/chooseUs/chooseUsFactRoute.js";
import footerRoute from "./routes/footer/footerRoute.js";
import footerCategoryRoute from "./routes/footer/footerCategoryRoute.js";
import footerLeftSideRoute from "./routes/footer/footerLeftSideRoute.js";

import path from "path";

const app = express();

dotenv.config();

dbConnection();

app.use(cors());

app.use(cookieParser());

app.use(express.json());

app.use(morgan("tiny"));

const __dirname = path.dirname("");
const buildPath = path.join(__dirname, "build");
app.use(express.static(buildPath));

// Serve static files from the "uploads" directory
app.use("/uploads", express.static("uploads"));

// routes
app.use("/api/get-in-touch", getInTouchRoute);

// about routes
app.use("/api/about/banner", aboutBannerRoute);
app.use("/api/about/header", aboutHeaderRoute);
app.use("/api/about/features", aboutFeaturesRoute);
app.use("/api/about/history-header", aboutHistoryHeaderRoute);
app.use("/api/about/history-work", aboutHistoryWorkRoute);
app.use("/api/about/choose-header", aboutChooseHeaderRoute);
app.use("/api/about/choose-service", aboutChooseServiceRoute);

// home routes
app.use("/api/home/slider", homeSliderRoute);
app.use("/api/home/header", homeHeaderRoute);
app.use("/api/home-projects/header", homeProjectsHeaderRoute);
app.use("/api/home/header-point", homeHeaderPointRoute);
app.use("/api/home/service", homeServiceRoute);
app.use("/api/home/brand", homeBrandRoute);

// project routes
app.use("/api/project/banner", projectBannerRoute);
app.use("/api/project/bottom", projectBottomRoute);
app.use("/api/project", projectRoute);

// contact routes
app.use("/api/contact-us/banner", contactBannerRoute);
app.use("/api/contact-us/header", contactHeaderRoute);
app.use("/api/contact-us/form", contactFormRoute);
app.use("/api/contact-us/footer/content", contactFooterRoute);
app.use("/api/contact-us/footer/company", contactFooterCompanyRoute);
app.use("/api/contact-us/footer/country", contactFooterCountryRoute);

// support route
app.use("/api/support", supportRoute);

// subscribe route
app.use("/api/subscribe", subscribeRoute);

// logo route
app.use("/api/logo", logoRoute);

// service routes
app.use("/api/service/banner", serviceBannerRoute);
app.use("/api/service/header", serviceHeaderRoute);
app.use("/api/service", serviceRoute);

// choose us routes
app.use("/api/chooseus/header", chooseUsHeaderRoute);
app.use("/api/chooseus/progress", chooseUsProgressRoute);
app.use("/api/chooseus/fact", chooseUsFactRoute);

// footer routes
app.use("/api/footer", footerRoute);
app.use("/api/footer/category", footerCategoryRoute);
app.use("/api/footer/left-side", footerLeftSideRoute);

// user authentication =======
app.use("/api/user", authRoute);

// app.use("/", express.static(path.join(__dirname, "build")));

const PORT = process.env.PORT || 8080;

app.listen(PORT, () => {
  console.log(`server is running on ${PORT}`.bgYellow);
});

// app.get("/", (req, res) => {
//   res.sendFile(path.join(__dirname, "build"));
// });

// app.get("/*", (req, res) => {
//   res.sendFile(path.join(__dirname, "build", "index.html"));
// });
