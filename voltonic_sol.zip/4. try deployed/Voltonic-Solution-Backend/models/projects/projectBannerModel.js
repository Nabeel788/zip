import mongoose from "mongoose";

const projectBannerSchema = new mongoose.Schema({
  image: {
    type: String,
  },
});

export default mongoose.model("projectBanner", projectBannerSchema);
