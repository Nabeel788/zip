import mongoose from "mongoose";

const projectSchema = new mongoose.Schema({
  categoryName: {
    type: String,
    required: true,
  },
  heading: {
    type: String,
    required: true,
  },
  title: {
    type: String,
    required: true,
  },
  description: {
    type: String,
    required: true,
  },
  client: {
    type: String,
  },
  referenceLink: {
    type: String,
  },
  projectDate: {
    type: Date,
  },
  image: {
    type: String,
  },
  videoUrl: {
    type: String,
  },
});

export default mongoose.model("projects", projectSchema);
