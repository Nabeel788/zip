import mongoose from "mongoose";

const homeBrandSchema = new mongoose.Schema({
  image: {
    type: String,
  },
});

export default mongoose.model("homeBrand", homeBrandSchema);
