import mongoose from "mongoose";

const homeHeaderSchema = new mongoose.Schema({
  companyName: {
    type: String,
    required: true,
  },
  description: {
    type: String,
    required: true,
  },
  image: {
    type: String,
  },
  videoUrl: {
    type: String,
  },
});

export default mongoose.model("homeHeader", homeHeaderSchema);
