import mongoose from "mongoose";

const homeSliderSchema = new mongoose.Schema({
  heading: {
    type: String,
  },
  description: {
    type: String,
  },
  url: {
    type: String,
  },
  image: {
    type: String,
  },
});

export default mongoose.model("homeSlider", homeSliderSchema);
