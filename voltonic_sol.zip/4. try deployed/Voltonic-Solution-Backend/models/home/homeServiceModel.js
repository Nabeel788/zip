import mongoose from "mongoose";

const homeServiceSchema = new mongoose.Schema({
  heading: {
    type: String,
    required: true,
  },
  description: {
    type: String,
  },
  iconClass: {
    type: String,
    required: true,
  },
});

export default mongoose.model("homeService", homeServiceSchema);
