import mongoose from "mongoose";

const homeHeaderPointSchema = new mongoose.Schema({
  bulletPoint: {
    type: String,
    required: true,
  },
});

export default mongoose.model("homeHeaderPoint", homeHeaderPointSchema);
