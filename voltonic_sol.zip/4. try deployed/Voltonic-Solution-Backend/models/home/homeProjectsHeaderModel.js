import mongoose from "mongoose";

const homeProjectsHeaderSchema = new mongoose.Schema({
  heading: {
    type: String,
    required: true,
  },

  description: {
    type: String,
    required: true,
  },
});

export default mongoose.model("homeProjectsHeader", homeProjectsHeaderSchema);
