import mongoose from "mongoose";

const serviceBannerSchema = new mongoose.Schema({
  image: {
    type: String,
  },
});

export default mongoose.model("serviceBanner", serviceBannerSchema);
