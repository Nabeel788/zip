import mongoose from "mongoose";

const serviceSchema = new mongoose.Schema({
  categoryName: {
    type: String,
    required: true,
  },
  heading: {
    type: String,
    required: true,
  },
  title: {
    type: String,
    required: true,
  },
  description: {
    type: String,
    required: true,
  },
  iconClass: {
    type: String,
  },
  image: {
    type: String,
  },
});

export default mongoose.model("services", serviceSchema);
