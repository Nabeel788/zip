import mongoose from "mongoose";

const serviceHeaderSchema = new mongoose.Schema({
  heading: {
    type: String,
    required: true,
  },
  description: {
    type: String,
  },
});

export default mongoose.model("serviceHeader", serviceHeaderSchema);
