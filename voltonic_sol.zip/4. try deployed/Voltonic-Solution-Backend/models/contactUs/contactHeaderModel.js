import mongoose from "mongoose";

const contactHeaderSchema = new mongoose.Schema({
  heading: {
    type: String,
    required: true,
  },
  description: {
    type: String,
  },
  googleMapDirection: {
    type: String,
  },
});

export default mongoose.model("contactHeader", contactHeaderSchema);
