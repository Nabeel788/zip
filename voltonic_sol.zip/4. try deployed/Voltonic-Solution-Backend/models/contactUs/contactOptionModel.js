import mongoose from "mongoose";

const contactCountrySchema = new mongoose.Schema({
  optionName: {
    type: String,
    required: true,
  },
});

export default mongoose.model("contactCountry", contactCountrySchema);
