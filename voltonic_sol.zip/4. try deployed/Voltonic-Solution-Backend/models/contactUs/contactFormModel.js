import mongoose from "mongoose";

const contactFormSchema = new mongoose.Schema({
  yourName: {
    type: String,
    required: true,
  },
  email: {
    type: String,
    required: true,
  },
  location: {
    type: String,
    required: true,
  },
  message: {
    type: String,
    required: true,
  },
});

export default mongoose.model("contactForm", contactFormSchema);
