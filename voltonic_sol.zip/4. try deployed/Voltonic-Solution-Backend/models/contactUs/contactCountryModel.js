import mongoose from "mongoose";

const contactCountrySchema = new mongoose.Schema({
  countryName: {
    type: String,
    required: true,
  },
});

export default mongoose.model("contactCountry", contactCountrySchema);
