import mongoose from "mongoose";

const contactFooterOptionSchema = new mongoose.Schema({
  optionName: {
    type: String,
    required: true,
  },
  optionLink: {
    type: String,
  },
});

const contactFooterSchema = new mongoose.Schema({
  companyName: {
    type: String,
  },
  countryName: {
    type: String,
  },
  options: [contactFooterOptionSchema],
});

export default mongoose.model("contactFooter", contactFooterSchema);
