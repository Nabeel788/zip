import mongoose from "mongoose";

const contactFooterCountrySchema = new mongoose.Schema({
  countryName: {
    type: String,
    required: true,
  },
});

export default mongoose.model(
  "contactFooterCountry",
  contactFooterCountrySchema
);
