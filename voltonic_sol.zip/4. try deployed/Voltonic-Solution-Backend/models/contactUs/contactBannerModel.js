import mongoose from "mongoose";

const contactBannerSchema = new mongoose.Schema({
  image: {
    type: String,
  },
});

export default mongoose.model("contactBanner", contactBannerSchema);
