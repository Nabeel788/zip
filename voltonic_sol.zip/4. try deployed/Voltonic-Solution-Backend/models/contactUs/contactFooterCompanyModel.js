import mongoose from "mongoose";

const contactFooterCompanySchema = new mongoose.Schema({
  companyName: {
    type: String,
    required: true,
  },
});

export default mongoose.model(
  "contactFooterCompanytegory",
  contactFooterCompanySchema
);
