import mongoose from "mongoose";

const logoSchema = new mongoose.Schema({
  image: {
    type: String,
  },
});

export default mongoose.model("logo", logoSchema);
