import mongoose from "mongoose";

const supportSchema = new mongoose.Schema({
  heading: {
    type: String,
    required: true,
  },
  description: {
    type: String,
    required: true,
  },
  iconClass: {
    type: String,
    required: true,
  },
});

export default mongoose.model("support", supportSchema);
