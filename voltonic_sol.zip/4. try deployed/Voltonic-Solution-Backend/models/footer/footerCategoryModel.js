import mongoose from "mongoose";

const footerCategorySchema = new mongoose.Schema({
  categoryName: {
    type: String,
    required: true,
  },
});

export default mongoose.model("footerCategory", footerCategorySchema);
