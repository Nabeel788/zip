import mongoose from "mongoose";

const footerLeftSideSchema = new mongoose.Schema({
  heading: {
    type: String,
    required: true,
  },
  description: {
    type: String,
  },
});

export default mongoose.model("footerLeftSide", footerLeftSideSchema);
