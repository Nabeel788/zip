import mongoose from "mongoose";

const footerOptionSchema = new mongoose.Schema({
  optionName: {
    type: String,
    required: true,
  },
  optionLink: {
    type: String,
  },
});

const footerSchema = new mongoose.Schema({
  categoryName: {
    type: String,
    required: true,
  },
  options: [footerOptionSchema],
});

export default mongoose.model("footer", footerSchema);
