// import mongoose from "mongoose";

// const commonSchema = new mongoose.Schema({
//   name: {
//     type: String,
//     required: true,
//   },
//   company: {
//     type: String,
//   },
//   image: {
//     type: String,
//   },
//   feedback: {
//     type: String,
//     required: true,
//   },
//   reference: {
//     type: String,
//   },
// });

// export default mongoose.model("testimonials", testimonialSchema);
