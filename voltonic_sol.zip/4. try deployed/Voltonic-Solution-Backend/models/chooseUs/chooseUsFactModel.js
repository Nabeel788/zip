import mongoose from "mongoose";

const chooseUsFactSchema = new mongoose.Schema({
  factName: {
    type: String,
    required: true,
  },
  count: {
    type: Number,
    required: true,
  },
  iconClass: {
    type: String,
  },
});

export default mongoose.model("chooseUsFact", chooseUsFactSchema);
