import mongoose from "mongoose";

const chooseUsProgressSchema = new mongoose.Schema({
  progressName: {
    type: String,
    required: true,
  },
  percentage: {
    type: Number,
    required: true,
  },
});

export default mongoose.model("chooseUsProgress", chooseUsProgressSchema);
