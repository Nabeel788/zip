import mongoose from "mongoose";

const aboutHeaderSchema = new mongoose.Schema({
  title: {
    type: String,
    required: true,
  },
  heading: {
    type: String,
    required: true,
  },
  description: {
    type: String,
  },
  image: {
    type: String,
  },
});

export default mongoose.model("aboutHeader", aboutHeaderSchema);
