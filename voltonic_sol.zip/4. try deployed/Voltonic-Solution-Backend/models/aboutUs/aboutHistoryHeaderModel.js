import mongoose from "mongoose";

const aboutHistoryHeaderSchema = new mongoose.Schema({
  title: {
    type: String,
    required: true,
  },
  description: {
    type: String,
    required: true,
  },
});

export default mongoose.model("aboutHistoryHeader", aboutHistoryHeaderSchema);
