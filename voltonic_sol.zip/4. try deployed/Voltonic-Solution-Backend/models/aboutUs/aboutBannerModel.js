import mongoose from "mongoose";

const aboutBannerSchema = new mongoose.Schema({
  image: {
    type: String,
  },
});

export default mongoose.model("aboutBanner", aboutBannerSchema);
