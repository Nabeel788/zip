import mongoose from "mongoose";

const aboutChooseHeaderSchema = new mongoose.Schema({
  title: {
    type: String,
    required: true,
  },
  description: {
    type: String,
    required: true,
  },
});

export default mongoose.model("aboutChooseHeader", aboutChooseHeaderSchema);
