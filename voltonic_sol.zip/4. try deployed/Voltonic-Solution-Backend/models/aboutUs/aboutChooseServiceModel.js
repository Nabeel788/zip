import mongoose from "mongoose";

const aboutChooseServiceSchema = new mongoose.Schema({
  heading: {
    type: String,
    required: true,
  },
  name: {
    type: String,
    required: true,
  },
  iconClass: {
    type: String,
    required: true,
  },
  url: {
    type: String,
    required: true,
  },
  image: {
    type: String,
  },
});

export default mongoose.model("aboutChooseService", aboutChooseServiceSchema);
