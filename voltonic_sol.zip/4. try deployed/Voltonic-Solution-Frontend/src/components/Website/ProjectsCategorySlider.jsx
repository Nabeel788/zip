import React, { useState, useRef } from "react";
import Slider from "react-slick";

const ProjectCategorySlider = ({ categories, filterProjects }) => {
  const [selectedCategory, setSelectedCategory] = useState("All Projects");
  const sliderRef = useRef();

  const settings = {
    infinite: false,
    speed: 500,
    slidesToShow: 4,
    slidesToScroll: 1,
    centerMode: false,
    variableWidth: true,
  };

  const handleCategoryClick = (categoryName) => {
    setSelectedCategory(categoryName);
    filterProjects(categoryName);
  };

  const handlePrev = () => {
    sliderRef.current.slickPrev();
  };

  const handleNext = () => {
    sliderRef.current.slickNext();
  };

  return (
    <div className="gallery-filter">
      <div className="slider-nav">
        <button className="btn btn-success slider-prev" onClick={handlePrev}>
          <i className="fa fa-chevron-left" />
        </button>
        <Slider ref={sliderRef} {...settings}>
          <div
            className={`filter ${
              selectedCategory === "All Projects" ? "active" : ""
            }`}
            onClick={() => handleCategoryClick("All Projects")}
          >
            <button className="btn btn-info">
              <i className="industrio-icon-layers" />
              All Projects
            </button>
          </div>
          {Object.keys(categories).map((categoryName) => (
            <div
              key={categoryName}
              className={`filter ${
                selectedCategory === categoryName ? "active" : ""
              }`}
              onClick={() => handleCategoryClick(categoryName)}
            >
              <button className="btn btn-primary">{categoryName}</button>
            </div>
          ))}
        </Slider>
        <button className="btn btn-success slider-next" onClick={handleNext}>
          <i className="fa fa-chevron-right" />
        </button>
      </div>
    </div>
  );
};

export default ProjectCategorySlider;
