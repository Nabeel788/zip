import React from "react";
import Slider from "react-slick";

const MiniSlider = ({ images }) => {
  const settings = {
    infinite: true,
    speed: 500,
    slidesToShow: 4, // Adjust the number of visible slides
    slidesToScroll: 1,
    draggable: true,
    arrows: true, // Show navigation arrows
    autoplay: true, // Enable autoplay
    autoplaySpeed: 3000, // Set the autoplay interval in milliseconds (3 seconds in this example)
  };

  return (
    <div className="mini-slider" {...settings}>
      <span>
        {images?.map((image, index) => (
          <div key={index}>
            <img src={`/uploads/${image}`} />
          </div>
        ))}
      </span>
    </div>
  );
};

export default MiniSlider;
