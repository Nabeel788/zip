import React, { useState, useEffect } from "react";
import axios from "axios";
import Slider from "react-slick";

const MyCarousel = () => {
  const [historyWork, setHistoryWorkData] = useState([]);
  var settings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
  };
  useEffect(() => {
    const loadItems = async () => {
      const { data } = await axios.get("/api/about/history-work/show-all");
      setHistoryWorkData(data);
    };
    loadItems();
  }, []);

  return (
    <>
      <>
        {/* Main Slider */}
        {/* <section className="main-slider">
          <div
            className="rev_slider_wrapper fullwidthbanner-container"
            id="rev_slider_one_wrapper"
            data-source="gallery"
          >
            <div
              className="rev_slider fullwidthabanner"
              id="rev_slider_one"
              data-version="5.4.1"
            >
              <ul>
                {historyWork.map((d) => (
                  <li
                    className="slide-1"
                    data-description="Slide Description"
                    data-easein="default"
                    data-easeout="default"
                    data-fsmasterspeed="1500"
                    data-fsslotamount="7"
                    data-fstransition="slotzoom-horizontal"
                    data-hideafterloop="0"
                    data-hideslideonmobile="off"
                    data-index="rs-1687"
                    data-masterspeed="default"
                    data-param1=""
                    data-param10=""
                    data-param2=""
                    data-param3=""
                    data-param4=""
                    data-param5=""
                    data-param6=""
                    data-param7=""
                    data-param8=""
                    data-param9=""
                    data-rotate="0"
                    data-saveperformance="off"
                    data-slotamount="default"
                    data-thumb={`/uploads/${d.image}`}
                    data-title="Slide Title"
                    data-transition="parallaxvertical"
                  >
                    <img
                      alt=""
                      className="rev-slidebg"
                      data-bgfit="cover"
                      data-bgparallax="10"
                      data-bgposition="center center"
                      data-bgrepeat="no-repeat"
                      data-no-retina=""
                      src={`/uploads/${d.image}`}
                    />

                    <div
                      className="tp-caption"
                      data-paddingbottom="[0,0,0,0]"
                      data-paddingleft="[0,0,0,0]"
                      data-paddingright="[0,0,0,0]"
                      data-paddingtop="[0,0,0,0]"
                      data-responsive_offset="on"
                      data-type="text"
                      data-height="none"
                      data-width="['650','750','700','420']"
                      data-whitespace="normal"
                      data-hoffset="['15','15','15','15']"
                      data-voffset="['-90','-80','-100','-80']"
                      data-x="['center','center','center','center']"
                      data-y="['middle','middle','middle','middle']"
                      data-textalign="['top','top','top','top']"
                      style={{
                        zIndex: "7",
                        whiteSpace: "nowrap",
                        textAlign: "center",
                      }}
                    >
                      <h2>
                        We will provide the <br /> best <span>Industrial</span>{" "}
                        service
                      </h2>
                    </div>

                    <div
                      className="tp-caption tp-resizeme"
                      data-paddingbottom="[0,0,0,0]"
                      data-paddingleft="[0,0,0,0]"
                      data-paddingright="[0,0,0,0]"
                      data-paddingtop="[0,0,0,0]"
                      data-responsive_offset="on"
                      data-type="text"
                      data-height="none"
                      data-width="['550','600','650','420']"
                      data-whitespace="normal"
                      data-hoffset="['15','15','15','15']"
                      data-voffset="['50','40','25','15']"
                      data-x="['center','center','center','center']"
                      data-y="['middle','middle','middle','middle']"
                      data-textalign="['top','top','top','top']"
                      style={{
                        zIndex: "7",
                        whiteSpace: "nowrap",
                        textAlign: "center",
                      }}
                    >
                      <a
                        href="#"
                        className="theme-btn btn-style-one hvr-sweep-to-right"
                      >
                        Learn more <i className="fa fa-arrow-right" />
                      </a>
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </section> */}
        {/*End Main Slider*/}
      </>
      {/* <Slider {...settings}>
        <div>
          <img
            key="1"
            src="./assets/website/img/banner/banner-1.jpg"
            alt="abc"
          />
        </div>
        <div>
          <img
            key="2"
            src="./assets/website/img/banner/banner-2.jpg"
            alt="abc"
          />
        </div>
        <div>
          <img
            key="3"
            src="./assets/website/img/banner/banner-3.jpg"
            alt="abc"
          />
        </div>
      </Slider> */}
    </>
  );
};

export default MyCarousel;
