import axios from "axios";
import React, { useState, useEffect } from "react";
import "react-responsive-carousel/lib/styles/carousel.min.css"; // Import the CSS
import { Link } from "react-router-dom";
const HomeSlider = () => {
  const [homeSlider, setHomeSlider] = useState([]);

  useEffect(() => {
    const loadItems = async () => {
      const { data } = await axios.get("/api/home/slider/show-all");
      setHomeSlider(data);
      console.log(data);
    };
    loadItems();
  }, []);

  return (
    <>
      <div
        id="minimal-bootstrap-carousel"
        className="carousel slide carousel-fade slider-home-one slider-home-two"
        data-ride="carousel"
      >
        {/* Wrapper for slides */}
        <div className="carousel-inner" role="listbox">
          {homeSlider?.map((slider, index) => (
            <div
              className={`item ${index === 0 ? "active" : ""} slide-${
                index + 1
              }`}
              style={{
                backgroundImage: `url(/uploads/${slider.image})`,
                backgroundPosition: "center center",
              }}
            >
              <div className="carousel-caption">
                <div className="container">
                  <div className="box valign-middle">
                    <div className="content text-center">
                      <h2
                        data-animation="animated fadeInUp"
                        style={{ fontSize: "70px" }}
                      >
                        {slider.heading}
                      </h2>
                      <p
                        data-animation="animated fadeInDown"
                        style={{ color: "#DCDCDB" }}
                      >
                        {slider.description}
                      </p>
                      <Link
                        to={slider.url}
                        className="banner-btn hvr-sweep-to-right text-decoration-none"
                        data-animation="animated fadeInDown"
                      >
                        Learn more <i className="fa fa-arrow-right" />
                      </Link>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
        {/* Controls */}
        <a
          className="left carousel-control"
          href="#minimal-bootstrap-carousel"
          role="button"
          data-slide="prev"
        >
          <i className="fas fa-angle-left" />
          <span className="sr-only">Previous</span>
        </a>
        <a
          className="right carousel-control"
          href="#minimal-bootstrap-carousel"
          role="button"
          data-slide="next"
        >
          <i className="fas fa-angle-right" />
          <span className="sr-only">Next</span>
        </a>
        <ul className="carousel-indicators list-inline custom-navigation">
          {homeSlider.map((slider, index) => (
            <li
              key={index}
              data-target="#minimal-bootstrap-carousel"
              data-slide-to={index}
              className={index === 0 ? "active" : ""}
            />
          ))}
        </ul>
        {/* /.logo home-two */}
      </div>
    </>

    // <div className="image-slider-container">
    //   <Carousel
    //     showArrows={false}
    //     showStatus={false}
    //     showThumbs={false}
    //     selectedItem={currentIndex}
    //     onChange={handleChange}
    //     infiniteLoop={true}
    //     autoPlay={true}
    //     stopOnHover={true}
    //     interval={5000}
    //   >
    //     {images?.map((myImage, index) => (
    //       <div key={index} className="image-slide">
    //         <img src={`uploads/${myImage.image}`} alt={`Slide ${index + 1}`} />
    //       </div>
    //     ))}
    //   </Carousel>
    // </div>
  );
};

export default HomeSlider;
