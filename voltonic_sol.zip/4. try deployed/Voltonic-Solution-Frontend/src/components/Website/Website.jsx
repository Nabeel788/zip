import React from "react";
import Navbar from "./Navbar";
import Footer from "./Footer";

const Website = ({ Component }) => {
  return (
    <div className="page-wrapper">
      <Navbar />
      <Component />
      <Footer />
    </div>
  );
};

export default Website;
