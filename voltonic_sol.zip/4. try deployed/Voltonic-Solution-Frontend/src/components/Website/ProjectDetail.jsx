import axios from "axios";
import React, { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";

const ProjectDetail = ({}) => {
  const [bannerImage, setBannerImage] = useState([]);
  const [existingImage, setExistingImage] = useState("");
  const [userData, setUserData] = useState({
    categoryName: "",
    heading: "",
    title: "",
    description: "",
    client: "",
    projectDate: null,
    referenceLink: "",
    videoUrl: "",
  });
  const { id } = useParams();

  useEffect(() => {
    const loadItems = async () => {
      const { data } = await axios.get("/api/project/banner/show-all");
      setBannerImage(data);
      console.log(data);
    };
    loadItems();
  }, []);

  useEffect(() => {
    const loadItems = async () => {
      try {
        const response = await axios.get(`/api/project/get-single-item/${id}`);
        const itemData = response.data;

        setUserData({
          title: itemData.title,
          heading: itemData.heading,
          description: itemData.description,
          categoryName: itemData.categoryName,
          client: itemData.client,
          projectDate: itemData.projectDate.substring(0, 10),
          referenceLink: itemData.referenceLink,
          videoUrl: itemData.videoUrl,
        });
        console.log(itemData);
        setExistingImage(`/uploads/${itemData.image}`);
      } catch (error) {
        console.log(error);
      }
    };
    loadItems();
  }, [id]);

  const bannerStyle = {
    backgroundImage: `url(/uploads/${
      bannerImage.length > 0 ? bannerImage[0].image : ""
    })`,
    backgroundPosition: "center center",
    backgroundRepeat: "no-repeat",
    backgroundSize: "cover",
  };

  return (
    <>
      <div class="inner-banner" style={bannerStyle}>
        <div class="container">
          <h3>Project Details</h3>
          <ul class="breadcumb">
            <li>
              <Link to="/">Home</Link>
            </li>
            <li>
              <span class="sep">
                <i class="fa fa-angle-right"></i>
              </span>
            </li>
            <li>
              <span>Project Details</span>
            </li>
          </ul>
        </div>
      </div>

      <section class="project-details">
        <div class="container">
          <div class="row">
            <div class="col-lg-7 col-md-12 col-sm-12 col-xs-12">
              <img
                className="img-fluid"
                src={existingImage}
                alt={userData.title}
              />
            </div>

            <div class="col-lg-5 col-md-12 col-sm-12 col-xs-12">
              <div class="project-details-content">
                <h3>{userData.title}</h3>
                <br />
                <p>{userData.description}</p>
                <br />
                <ul class="meta-info">
                  <li>
                    <i class="fa fa-tag"></i>
                    <span>Category:</span>
                    {userData.categoryName}
                  </li>
                  {userData.client && (
                    <li>
                      <i class="fa fa-user"></i>
                      <span>Client:</span>
                      {userData.client}
                    </li>
                  )}
                  <li>
                    <i class="fa fa-calendar-alt"></i>
                    <span>Date:</span>
                    {userData.projectDate}
                  </li>
                  {userData.referenceLink && (
                    <li>
                      <i class="fa fa-external-link-alt"></i>
                      <span>Link:</span> {userData.referenceLink}
                    </li>
                  )}
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default ProjectDetail;
