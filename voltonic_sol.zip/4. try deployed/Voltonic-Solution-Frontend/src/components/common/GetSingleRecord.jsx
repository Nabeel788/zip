import React, { useEffect } from "react";
import axios from "axios";

const GetSingleRecord = ({ id, setters, route }) => {
  useEffect(() => {
    const loadItems = async () => {
      try {
        const response = await axios.get(route);
        const itemData = response.data;

        console.log(itemData);

        array.forEach((setter, index) => {
          setter(itemData[index]);
        });
      } catch (error) {
        console.log(error);
      }
    };
    loadItems();
  }, [id, setters]);
  return null;
};

export default GetSingleRecord;
