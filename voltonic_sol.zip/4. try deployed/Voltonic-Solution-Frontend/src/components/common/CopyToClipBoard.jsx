import React, { useRef } from "react";
import Button from "./Button";
import { toast } from "react-toastify";

const CopyToClipboard = ({ textToCopy }) => {
  const inputRef = useRef(null);

  const toastMessages = {
    textCopied: "Text Copied",
  };

  const handleCopyClick = () => {
    const copyText = inputRef.current;

    if (copyText) {
      copyText.select();
      copyText.setSelectionRange(0, 99999); // For mobile devices

      navigator.clipboard
        .writeText(copyText.value)
        .then(() => {
          notifyCreate(toastMessages.textCopied);
        })
        .catch((error) => {
          console.error("Unable to copy text to clipboard", error);
        });
    }
  };

  const notifyCreate = (message) => toast.success(message);

  return (
    <div>
      <textarea
        id="myInput"
        ref={inputRef}
        defaultValue={textToCopy}
        style={{ display: "none" }}
      />

      <Button
        name="Copy"
        onClick={handleCopyClick}
        className="fw-bold btn btn-primary"
      />
    </div>
  );
};

export default CopyToClipboard;
