import React, { useState } from "react";
import axios from "axios";
import "react-toastify/dist/ReactToastify.css";
import { ToastContainer, toast } from "react-toastify";
import Input from "../../../common/Input";
import Button from "../../../common/Button";
import TextArea from "../../../common/TextArea";

const Form = ({
  inputFields,
  textAreas,
  isImage,
  getSingleRecordRoute,
  addSingleRecordRoute,
  updateSingleRecordRoute,
}) => {
  const addSingleRecordRoute = addSingleRecordRoute;
  const getSingleRecordRoute = getSingleRecordRoute;
  const updateSingleRecordRoute = updateSingleRecordRoute;

  const generateInitialState = () => {
    const initialState = {};
    inputFields.forEach((field) => {
      initialState[field] = "";
    });
    return initialState;
  };

  const [userData, setUserData] = useState(generateInitialState());

  const handleChange = (e) => {
    const { name, value } = e.target;
    setUserData({
      ...userData,
      [name]: value,
    });
  };

  const [image, setImage] = useState(null);
  const [fileSizeError, setFileSizeError] = useState(false);

  const toastMessages = {
    created: "Created Successfully",
    error: "something Bad Happend",
    titleError: "Title is missing",
    descriptionError: "Description is missing",
    headingError: "Heading is missing",
    categoryNameError: "Category Name is missing",
    clientError: "Client is missing",
    referenceLinkError: "Reference Link is missing",
    headingError: "Heading is missing",
    videoUrlError: "Video Url is missing",
    imageError: "image is missing",
    imageSizeError: "Please choose file less than 5 MB",
  };

  const notifyCreate = (message) => toast.success(message);
  const notifyError = (message) => toast.error(message);

  const inputHandler = (event) => {
    const { name, value } = event.target;
    setUserData({ ...userData, [name]: value });
  };

  const handleImageChange = (e) => {
    const selectedFile = e.target.files[0];

    if (selectedFile && selectedFile.size > 5 * 1024 * 1024) {
      setFileSizeError(true);
      try {
        notifyError(toastMessages.imageSizeError);
      } catch (error) {
        console.log(error);
      }
    } else {
      setFileSizeError(false);
      setImage(selectedFile);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const {
      title,
      heading,
      description,
      categoryName,
      client,
      projectDate,
      referenceLink,
      videoUrl,
    } = userData;

    const formData = new FormData();
    formData.append("title", title);
    formData.append("heading", heading);
    formData.append("description", description);
    formData.append("categoryName", categoryName);
    formData.append("client", client);
    formData.append("projectDate", projectDate);
    formData.append("referenceLink", referenceLink);
    formData.append("videoUrl", videoUrl);
    formData.append("image", image);

    if (!fileSizeError) {
      switch (true) {
        case !heading:
          notifyError(toastMessages.headingError);
          break;

        case !title:
          notifyError(toastMessages.titleError);
          break;

        case !description:
          notifyError(toastMessages.descriptionError);
          break;

        case !categoryName:
          notifyError(toastMessages.categoryNameError);
          break;

        case !client:
          notifyError(toastMessages.clientError);
          break;

        case !projectDate:
          notifyError(toastMessages.projectDateError);
          break;

        case !referenceLink:
          notifyError(toastMessages.referenceLinkError);
          break;

        case !videoUrl:
          notifyError(toastMessages.videoUrlError);
          break;

        case !image:
          notifyError(toastMessages.imageError);
          break;

        default:
          try {
            // send a POST request to the server to add the product
            const response = await axios.post(route, formData);
            notifyCreate(toastMessages.created);
            // handle the response and perform any necessary actions
            console.log(response);
            console.log(response.data);

            // reset the form
            setUserData({
              title: "",
              description: "",
              heading: "",
              categoryName: "",
              client: "",
              projectDate: null,
              referenceLink: "",
              videoUrl: "",
            });
            setImage(null);
          } catch (error) {
            notifyError(toastMessages.error);
            console.error(error);
          }
          break;
      }
    }
  };

  return (
    <div className="container">
      <h3 className="text-center">Add Project</h3>
      <div className="row">
        <form onSubmit={handleSubmit}>
          <tr className="d-flex justify-content-center">
            <td className="col-6">
              <Input
                value={userData.heading}
                onChange={inputHandler}
                id="Heading"
                placeholder="Heading"
                label="Heading"
                name="heading"
              />
              <Input
                value={userData.title}
                onChange={inputHandler}
                id="Title"
                placeholder="Title"
                label="Title"
                name="title"
              />
              <Input
                value={userData.categoryName}
                onChange={inputHandler}
                id="CategoryName"
                placeholder="Category Name"
                label="Category Name"
                name="categoryName"
              />
              <Input
                value={userData.client}
                onChange={inputHandler}
                id="Client"
                placeholder="Client"
                label="Client"
                name="client"
              />
              <Input
                value={userData.referenceLink}
                onChange={inputHandler}
                id="ReferenceLink"
                placeholder="ReferenceLink"
                label="ReferenceLink"
                name="referenceLink"
              />
            </td>
            <span className="m-2"></span>
            <td className="col-6">
              <Input
                type="date"
                value={userData.projectDate}
                onChange={inputHandler}
                id="Project Date"
                placeholder="Project Date"
                label="projectDate"
                name="projectDate"
              />
              <Input
                value={userData.videoUrl}
                onChange={inputHandler}
                id="VideoUrl"
                placeholder="Video Url"
                label="Video Url"
                name="videoUrl"
              />
              <TextArea
                name="description"
                value={userData.description}
                onChange={inputHandler}
                id="Description"
                boxHeight="5rem"
                label="Description"
              />
              <Input
                type="file"
                onChange={handleImageChange}
                id="Image"
                placeholder="Image"
                label="Image - Please select file less than 5 MB - 666 x 645"
              />
            </td>
          </tr>

          <div className="text-center">
            <Button name="Submit" type="submit" className="btn btn-primary" />
          </div>
        </form>
        <ToastContainer />
      </div>
    </div>
  );
};

export default Form;
