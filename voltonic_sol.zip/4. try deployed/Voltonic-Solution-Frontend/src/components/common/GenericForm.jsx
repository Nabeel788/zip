import React, { useEffect, useState } from "react";
import PropTypes from "prop-types";
import Input from "./Input";
import TextArea from "./TextArea";
import Button from "./Button";

const GenericForm = ({ fields, onSubmit, initialValue, mode }) => {
  const [formData, setFormData] = useState(initialValue || {});

  useEffect(() => {
    setFormData(initialValue || {});
  }, [initialValue]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(formData);
  };

  return (
    <form onSubmit={handleSubmit}>
      {fields.map((field, index) => (
        <div key={index} className="mb-3">
          {field.label && <label htmlFor={field.name}>{field.label}</label>}
          {field.type === "text" && (
            <Input
              id={field.name}
              name={field.name}
              value={formData[field.name] || ""}
              onChange={handleInputChange}
              placeholder={field.placeholder}
            />
          )}
          {field.type === "textarea" && (
            <TextArea
              id={field.name}
              name={field.name}
              value={formData[field.name] || ""}
              onChange={handleInputChange}
            />
          )}
          {/* You can add more input types (e.g., select, radio, checkbox) here */}
        </div>
      ))}
      <Button type="submit" name={mode === "update" ? "Update" : "Submit"} />
    </form>
  );
};

GenericForm.propTypes = {
  fields: PropTypes.arrayOf(
    PropTypes.shape({
      type: PropTypes.string.isRequired,
      label: PropTypes.string,
      name: PropTypes.string.isRequired,
      placeholder: PropTypes.string,
    })
  ).isRequired,
  onSubmit: PropTypes.func.isRequired,
  initialValue: PropTypes.object,
  mode: PropTypes.string,
};

export default GenericForm;
