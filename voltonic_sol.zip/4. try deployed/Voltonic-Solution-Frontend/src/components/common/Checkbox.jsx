import React from "react";

const Checkbox = ({ label = "Toggle Multiple Records", onChange }) => {
  return (
    <div
      className="btn-group"
      role="group"
      aria-label="Basic checkbox toggle button group"
    >
      <input
        type="checkbox"
        className="btn-check"
        id="btncheck1"
        autoComplete="off"
        onChange={onChange}
      />
      <label className="btn btn-outline-primary" htmlFor="btncheck1">
        {label}
      </label>
    </div>
  );
};

export default Checkbox;
