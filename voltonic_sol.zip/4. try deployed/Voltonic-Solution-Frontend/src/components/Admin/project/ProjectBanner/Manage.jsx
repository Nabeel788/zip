import GetAllRecords from "../../../common/GetAllRecords";
import { useState } from "react";
import Table from "../../../common/Table";

const Manage = () => {
  const getRoute = "/api/project/banner/show-all";
  const deleteRoute = `/api/project/banner/delete/`;
  const linkToUpdateComponent = `/admin/project/banner/update/`;
  const [data, setData] = useState([]);

  const onDelete = async (itemId) => {
    setData((prevData) => prevData.filter((item) => item._id !== itemId));
  };

  return (
    <div className="container">
      <h3 className="text-center">Manage Header</h3>
      <p className="text-warning fw-bold">Add only 1 Record</p>

      <GetAllRecords
        endpointToGetAllRecords={getRoute}
        endpointToDeleteRecord={deleteRoute}
        onDelete={onDelete}
      >
        {({ data, loading, handleDeleteInternal }) => (
          <>
            {loading ? (
              <p>Loading...</p>
            ) : (
              <Table
                data={data}
                handleDelte={handleDeleteInternal}
                updateLink={linkToUpdateComponent}
              />
            )}
          </>
        )}
      </GetAllRecords>
    </div>
  );
};

export default Manage;
