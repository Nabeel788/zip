import React, { useEffect, useState } from "react";
import axios from "axios";
import { Link, useParams } from "react-router-dom";
import { ToastContainer, toast } from "react-toastify";
import TextArea from "../../common/TextArea";
import Input from "../../common/Input";
import Button from "../../common/Button";

const UpdateAboutPage = () => {
  const [heading, setHeading] = useState("");
  const [description, setDescription] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const { id } = useParams();

  const created = "Created Successfully";
  const errorMessage = "something Bad Happend";
  const descriptionError = "Description is missing";
  const headingError = "Heading is missing";
  const phoneError = "Phone is missing";
  const emailError = "email is missing";

  const notifyCreate = (message) => toast.success(message);
  const notifyError = (message) => toast.error(message);

  useEffect(() => {
    const loadItems = async () => {
      try {
        const response = await axios.get(
          `/api/get-in-touch/get-single-item/${id}`
        );
        const aboutData = response.data;

        console.log(aboutData);
        setHeading(aboutData.heading);
        setDescription(aboutData.description);
        setEmail(aboutData.email);
        setPhone(aboutData.phone);
      } catch (error) {
        console.log(error);
      }
    };
    loadItems();
  }, [id]);

  const handleHeadingChange = (e) => {
    setHeading(e.target.value);
  };

  const handleDescriptionChange = (e) => {
    setDescription(e.target.value);
  };

  const handlePhoneChange = (e) => {
    setPhone(e.target.value);
  };

  const handleEmailChange = (e) => {
    setEmail(e.target.value);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    switch (true) {
      case !heading:
        notifyError(headingError);
        break;

      case !description:
        notifyError(descriptionError);
        break;

      case !phone:
        notifyError(phoneError);
        break;

      case !email:
        notifyError(emailError);
        break;

      default:
        try {
          // send a POST request to the server to add the product
          const response = await axios.post(`/api/get-in-touch/update/${id}`, {
            heading,
            description,
            phone,
            email,
          });
          notifyCreate(created);
          // handle the response and perform any necessary actions
          console.log(response);
          console.log(response.data);

          // reset the form
        } catch (error) {
          notifyError(errorMessage);
          console.error(error);
        }
        break;
    }
  };

  return (
    <div>
      <h3 className="text-center">Update Get-In-Touch</h3>
      <form onSubmit={handleSubmit}>
        <Input
          value={heading}
          onChange={handleHeadingChange}
          id="floatingInputHeading"
          placeholder="Heading"
          label="Heading"
        />
        <Input
          value={phone}
          onChange={handlePhoneChange}
          id="floatingInputPhone"
          placeholder="Phone"
          label="Phone"
        />
        <Input
          value={email}
          onChange={handleEmailChange}
          id="floatingInputEmail"
          placeholder="Email"
          label="Email"
        />
        <TextArea
          name="Description"
          value={description}
          onChange={handleDescriptionChange}
          id="floatingDescription2"
          boxHeight="5rem"
          label="Description"
        />
        <div className="text-center">
          <Button name="Update" type="submit" className="btn btn-warning" />
        </div>
      </form>
      <ToastContainer />
    </div>
  );
};

export default UpdateAboutPage;
