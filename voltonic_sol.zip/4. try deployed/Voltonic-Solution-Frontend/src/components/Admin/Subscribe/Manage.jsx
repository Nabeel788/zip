import axios from "axios";
import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";

const Manage = () => {
  const [data, setData] = useState([]);
  const [disable, setDisable] = useState(false);

  useEffect(() => {
    const loadItems = async () => {
      const { data } = await axios.get("/api/subscribe/show-all");
      setData(data);
      console.log(data);
    };
    loadItems();
  }, []);

  const handleDelete = async (itemId) => {
    try {
      await axios.delete(`/api/subscribe/delete/${itemId}`);
      // remove the deleted about from the data array
      setData((prevData) => prevData.filter((item) => item._id !== itemId));
      console.log("item deleted successfully");
    } catch (error) {
      console.error("failed to delete item", error);
    }
  };

  return (
    <div className="container">
      <h3 className="text-center">Manage Features</h3>
      <p className="text-warning fw-bold">Add only 1 Record</p>
      <table className="table table-striped  table-hover">
        <thead>
          <tr>
            <th scope="col">Email</th>
            <th scope="col">Operations</th>
          </tr>
        </thead>
        <tbody>
          {data.map((d) => (
            <tr key={d._id}>
              <td className="col">{d.email}</td>
              <td className="col">
                <button
                  className="btn btn-danger"
                  onClick={() => setDisable(!disable)}
                >
                  Unlock Delete Button
                </button>
                <span className="me-2 ms-2">|</span>
                <button
                  className="btn btn-danger"
                  onClick={() => handleDelete(d._id)}
                  disabled={!disable}
                >
                  Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default Manage;
