import React, { useEffect, useState } from "react";
import axios from "axios";
import { Link, useParams } from "react-router-dom";
import { ToastContainer, toast } from "react-toastify";
import TextArea from "../../../common/TextArea";
import Input from "../../../common/Input";
import Button from "../../../common/Button";
import Select from "../../../common/Select";

const Update = () => {
  const [categoryName, setCategoryName] = useState("");
  const [options, setOptions] = useState([]);
  const [optionName, setOptionName] = useState("");
  const [optionLink, setOptionLink] = useState("");
  const [categoryNames, setCategoryNames] = useState([]);
  const { id } = useParams();

  // error messages
  const created = "Created Successfully";
  const errorMessage = "something Bad Happend";
  const optionsError = "options is missing";
  const categoryNameError = "categoryName is missing";

  const notifyCreate = (message) => toast.success(message);
  const notifyError = (message) => toast.error(message);

  const handleCategoryNameChange = (e) => {
    setCategoryName(e.target.value);
  };

  const handleOptionNameChange = (e) => {
    setOptionName(e.target.value);
  };

  const handleOptionLinkChange = (e) => {
    setOptionLink(e.target.value);
  };

  const handleAddOption = () => {
    if (optionName) {
      setOptions([...options, { optionName, optionLink }]);
      setOptionName("");
      setOptionLink("");
    }
  };

  const handleRemoveOption = (index) => {
    // remove an option from the options arrays based on its index
    const newOptions = [...options];
    newOptions.splice(index, 1);
    setOptions(newOptions);
  };

  useEffect(() => {
    const loadItems = async () => {
      const { data } = await axios.get("/api/footer/category/show-all");
      setCategoryNames(data);
      console.log("category", data.categoryName);
      console.log("category", data);
    };
    loadItems();
  }, []);

  useEffect(() => {
    const loadItems = async () => {
      try {
        const response = await axios.get(`/api/footer/get-single-item/${id}`);
        const itemData = response.data;
        console.log(itemData);
        setCategoryName(itemData.categoryName);
        setOptions(itemData.options);
      } catch (error) {
        console.log(error);
      }
    };
    loadItems();
  }, [id]);

  const handleSubmit = async (e) => {
    e.preventDefault();

    switch (true) {
      case !categoryName:
        notifyError(categoryNameError);
        break;

      default:
        try {
          // send a POST request to the server to add the product
          const response = await axios.post(`/api/footer/update/${id}`, {
            categoryName,
            options,
          });
          notifyCreate(created);
          // handle the response and perform any necessary actions
          console.log(response);
          console.log(response.data);

          // reset the form
        } catch (error) {
          notifyError(errorMessage);
          console.error(error);
        }
        break;
    }
  };

  return (
    <div>
      <h3 className="text-center">Update Footer Content</h3>
      <form onSubmit={handleSubmit}>
        <Select
          name="Choose Category Name"
          options={categoryNames.map((item) => item.categoryName)}
          id="categoryNames"
          onChange={handleCategoryNameChange}
          placeholder="Category Names"
          label="Category Names"
          value={categoryName}
        />

        <div>
          <Input
            value={optionName}
            onChange={handleOptionNameChange}
            id="optionName"
            placeholder="Option Name"
            label="Option Name"
          />
          <Input
            value={optionLink}
            onChange={handleOptionLinkChange}
            id="optionLink"
            placeholder="Option Link"
            label="Option Link"
          />
          <Button
            className="btn btn-secondary"
            name="Add Option"
            type="button"
            onClick={handleAddOption}
          />
        </div>
        <div>
          <div className="col-4">
            <table class="table table-hover">
              <thead>
                <tr>
                  <th scope="col">Option Name</th>
                  <th scope="col">Option Link</th>
                  <th scope="col">Operation</th>
                </tr>
              </thead>
              <tbody>
                {options?.map((option, index) => (
                  <tr>
                    <td>{option.optionName || "N/A"}</td>
                    <td>{option.optionLink || "N/A"}</td>
                    <td>
                      <Button
                        type="button"
                        name="Remove Option"
                        className="btn btn-danger"
                        onClick={() => handleRemoveOption(index)}
                      />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
        <div className="text-center">
          <Button name="Update" type="submit" className="btn btn-warning" />
        </div>
      </form>
      <ToastContainer />
    </div>
  );
};

export default Update;
