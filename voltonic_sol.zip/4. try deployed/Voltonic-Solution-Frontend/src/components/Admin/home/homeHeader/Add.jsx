import React, { useState } from "react";
import axios from "axios";
import "react-toastify/dist/ReactToastify.css";
import { ToastContainer, toast } from "react-toastify";
import Input from "../../../common/Input";
import Button from "../../../common/Button";
import TextArea from "../../../common/TextArea";

const Add = () => {
  const [companyName, setCompanyName] = useState("");
  const [videoUrl, setvideoUrl] = useState("");
  const [description, setDescription] = useState("");
  const [image, setImage] = useState(null);
  const [fileSizeError, setFileSizeError] = useState(false);

  // error messages
  const created = "Created Successfully";
  const errorMessage = "something Bad Happend";
  const companyNameError = "companyName is missing";
  const descriptionError = "Description is missing";
  const videoUrlError = "videoUrl is missing";
  const imageError = "image is missing";
  const imageSizeError = "Please choose file less than 5 MB";

  const notifyCreate = (message) => toast.success(message);
  const notifyError = (message) => toast.error(message);

  const handleImageChange = (e) => {
    const selectedFile = e.target.files[0];

    if (selectedFile && selectedFile.size > 5 * 1024 * 1024) {
      setFileSizeError(true);
      try {
        notifyError(imageSizeError);
      } catch (error) {
        console.log(error);
      }
    } else {
      setFileSizeError(false);
      setImage(selectedFile);
    }
  };

  const handlecompanyNameChange = (e) => {
    setCompanyName(e.target.value);
  };

  const handlevideoUrlChange = (e) => {
    setvideoUrl(e.target.value);
  };

  const handleDescriptionChange = (e) => {
    setDescription(e.target.value);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const formData = new FormData();
    formData.append("companyName", companyName);
    formData.append("videoUrl", videoUrl);
    formData.append("description", description);
    formData.append("image", image);

    if (!fileSizeError) {
      switch (true) {
        case !videoUrl:
          notifyError(videoUrlError);
          break;

        case !companyName:
          notifyError(companyNameError);
          break;

        case !description:
          notifyError(descriptionError);
          break;

        case !image:
          notifyError(imageError);
          break;

        default:
          try {
            // send a POST request to the server to add the product
            const response = await axios.post("/api/home/header/add", formData);
            notifyCreate(created);
            // handle the response and perform any necessary actions
            console.log(response);
            console.log(response.data);

            // reset the form
            setCompanyName("");
            setvideoUrl("");
            setDescription("");
          } catch (error) {
            notifyError(errorMessage);
            console.error(error);
          }
          break;
      }
    }
  };

  return (
    <div>
      <h3 className="text-center">Add Home - Header</h3>
      <form onSubmit={handleSubmit} encType="multipart/form-data">
        <Input
          value={companyName}
          onChange={handlecompanyNameChange}
          id="floatingInputcompanyName"
          placeholder="companyName"
          label="companyName"
        />
        <Input
          value={videoUrl}
          onChange={handlevideoUrlChange}
          id="floatingInputvideoUrl"
          placeholder="videoUrl"
          label="videoUrl"
        />
        <TextArea
          name="Description"
          label="Description"
          value={description}
          onChange={handleDescriptionChange}
          id="floatingDescription2"
          boxHeight="5rem"
        />
        <Input
          type="file"
          onChange={handleImageChange}
          id="floatingInputImage"
          placeholder="Image"
          label="Image - Please select file less than 5 MB - 353 x 353"
        />
        <div className="text-center">
          <Button name="Submit" type="submit" className="btn btn-primary" />
        </div>
      </form>
      <ToastContainer />
    </div>
  );
};

export default Add;
