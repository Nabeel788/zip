import React, { useState } from "react";
import axios from "axios";
import "react-toastify/dist/ReactToastify.css";
import { ToastContainer, toast } from "react-toastify";
import Input from "../../../common/Input";
import Button from "../../../common/Button";

const Add = () => {
  const [bulletPoint, setBulletPoint] = useState("");

  // error messages
  const created = "Created Successfully";
  const errorMessage = "something Bad Happend";
  const bulletPointError = "bulletPoint is missing";

  const notifyCreate = (message) => toast.success(message);
  const notifyError = (message) => toast.error(message);

  const handlebulletPointChange = (e) => {
    setBulletPoint(e.target.value);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    switch (true) {
      case !bulletPoint:
        notifyError(bulletPointError);
        break;

      default:
        try {
          // send a POST request to the server to add the product
          const response = await axios.post("/api/home/header-point/add", {
            bulletPoint,
          });
          notifyCreate(created);
          // handle the response and perform any necessary actions
          console.log(response);
          console.log(response.data);

          // reset the form
          setBulletPoint("");
        } catch (error) {
          notifyError(errorMessage);
          console.error(error);
        }
        break;
    }
  };

  return (
    <div>
      <h3 className="text-center">Add Home - Header Point</h3>
      <form onSubmit={handleSubmit}>
        <Input
          value={bulletPoint}
          onChange={handlebulletPointChange}
          id="floatingInputbulletPoint"
          placeholder="bulletPoint"
          label="bulletPoint"
        />
        <div className="text-center">
          <Button name="Submit" type="submit" className="btn btn-primary" />
        </div>
      </form>
      <ToastContainer />
    </div>
  );
};

export default Add;
