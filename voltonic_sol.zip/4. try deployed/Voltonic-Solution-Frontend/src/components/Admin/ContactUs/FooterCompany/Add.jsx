import React, { useState } from "react";
import axios from "axios";
import "react-toastify/dist/ReactToastify.css";
import { ToastContainer, toast } from "react-toastify";
import Input from "../../../common/Input";
import Button from "../../../common/Button";

const Add = () => {
  const [companyName, setCompanyName] = useState("");

  // error messages
  const created = "Created Successfully";
  const errorMessage = "something Bad Happend";
  const companyNameError = "companyName is missing";

  const notifyCreate = (message) => toast.success(message);
  const notifyError = (message) => toast.error(message);

  const handlecompanyNameChange = (e) => {
    setCompanyName(e.target.value);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    switch (true) {
      case !companyName:
        notifyError(companyNameError);
        break;

      default:
        try {
          // send a POST request to the server to add the product
          const response = await axios.post(
            "/api/contact-us/footer/company/add",
            {
              companyName,
            }
          );
          notifyCreate(created);
          // handle the response and perform any necessary actions
          console.log(response);
          console.log(response.data);

          // reset the form
          setCompanyName("");
        } catch (error) {
          notifyError(errorMessage);
          console.error(error);
        }
        break;
    }
  };

  return (
    <div>
      <h3 className="text-center">Add Footer Company Name</h3>
      <form onSubmit={handleSubmit}>
        <Input
          value={companyName}
          onChange={handlecompanyNameChange}
          id="companyName"
          placeholder="Company Name"
          label="Company Name"
        />
        <div className="text-center">
          <Button name="Submit" type="submit" className="btn btn-primary" />
        </div>
      </form>
      <ToastContainer />
    </div>
  );
};

export default Add;
