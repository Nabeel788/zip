import React, { useEffect, useState } from "react";
import axios from "axios";
import { Link, useParams } from "react-router-dom";
import { ToastContainer, toast } from "react-toastify";
import TextArea from "../../../common/TextArea";
import Input from "../../../common/Input";
import Button from "../../../common/Button";

const Update = () => {
  const [yourName, setYourName] = useState("");
  const [email, setEmail] = useState("");
  const [location, setLocation] = useState("");
  const [message, setMessage] = useState("");
  const { id } = useParams();

  // error messages
  const created = "Created Successfully";
  const errorMessage = "something Bad Happend";
  const yourNameError = "Your Name is missing";
  const emailError = "Email is missing";
  const locationError = "Location is missing";
  const messageError = "Message is missing";

  const notifyCreate = (message) => toast.success(message);
  const notifyError = (message) => toast.error(message);

  useEffect(() => {
    const loadItems = async () => {
      try {
        const response = await axios.get(
          `/api/contact-us/form/get-single-item/${id}`
        );
        const itemData = response.data;

        console.log(itemData);
        setYourName(itemData.yourName);
        setEmail(itemData.email);
        setLocation(itemData.location);
        setMessage(itemData.message);
      } catch (error) {
        console.log(error);
      }
    };
    loadItems();
  }, [id]);
  const handleYourNameChange = (e) => {
    setYourName(e.target.value);
  };

  const handleEmailChange = (e) => {
    setEmail(e.target.value);
  };

  const handleLocationChange = (e) => {
    setLocation(e.target.value);
  };

  const handleMessageChange = (e) => {
    setMessage(e.target.value);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    switch (true) {
      case !yourName:
        notifyError(yourNameError);
        break;

      case !email:
        notifyError(emailError);
        break;

      case !location:
        notifyError(locationError);
        break;

      case !message:
        notifyError(messageError);
        break;

      default:
        try {
          // send a POST request to the server to add the product
          const response = await axios.post(
            `/api/contact-us/form/update/${id}`,
            {
              yourName,
              email,
              location,
              message,
            }
          );
          notifyCreate(created);
          // handle the response and perform any necessary actions
          console.log(response);
          console.log(response.data);

          // reset the form
        } catch (error) {
          notifyError(errorMessage);
          console.error(error);
        }
        break;
    }
  };

  return (
    <div>
      <h3 className="text-center">Update Contact Us Records</h3>
      <form onSubmit={handleSubmit}>
        <Input
          value={yourName}
          onChange={handleYourNameChange}
          id="floatingInputYourName"
          placeholder="YourName"
          label="YourName"
        />
        <Input
          value={email}
          onChange={handleEmailChange}
          id="floatingInputEmail"
          placeholder="Email"
          label="Email"
        />
        <Input
          value={location}
          onChange={handleLocationChange}
          id="floatingInputLocation"
          placeholder="Location"
          label="Location"
        />
        <TextArea
          name="Message"
          value={message}
          onChange={handleMessageChange}
          id="floatingMessage2"
          boxHeight="5rem"
        />
        <div className="text-center">
          <Button name="Submit" type="submit" className="btn btn-primary" />
        </div>
      </form>
      <ToastContainer />
    </div>
  );
};

export default Update;
