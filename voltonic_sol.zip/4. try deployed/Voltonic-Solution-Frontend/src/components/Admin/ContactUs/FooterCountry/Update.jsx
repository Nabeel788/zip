import React, { useEffect, useState } from "react";
import axios from "axios";
import { Link, useParams } from "react-router-dom";
import { ToastContainer, toast } from "react-toastify";
import TextArea from "../../../common/TextArea";
import Input from "../../../common/Input";
import Button from "../../../common/Button";

const Update = () => {
  const [countryName, setcountryName] = useState("");
  const { id } = useParams();

  // error messages
  const created = "Created Successfully";
  const errorMessage = "something Bad Happend";
  const countryNameError = "countryName is missing";

  const notifyCreate = (message) => toast.success(message);
  const notifyError = (message) => toast.error(message);

  const handleCountryNameChange = (e) => {
    setcountryName(e.target.value);
  };

  useEffect(() => {
    const loadItems = async () => {
      try {
        const response = await axios.get(
          `/api/contact-us/footer/country/get-single-item/${id}`
        );
        const itemData = response.data;

        console.log(itemData);
        setcountryName(itemData.countryName);
      } catch (error) {
        console.log(error);
      }
    };
    loadItems();
  }, [id]);

  const handleSubmit = async (e) => {
    e.preventDefault();

    switch (true) {
      case !countryName:
        notifyError(countryNameError);
        break;

      default:
        try {
          // send a POST request to the server to add the product
          const response = await axios.post(
            `/api/contact-us/footer/country/update/${id}`,
            {
              countryName,
            }
          );
          notifyCreate(created);
          // handle the response and perform any necessary actions
          console.log(response);
          console.log(response.data);

          // reset the form
        } catch (error) {
          notifyError(errorMessage);
          console.error(error);
        }
        break;
    }
  };

  return (
    <div>
      <h3 className="text-center">Update Footer Country Name</h3>
      <form onSubmit={handleSubmit}>
        <Input
          value={countryName}
          onChange={handleCountryNameChange}
          id="countryName"
          placeholder="Country Name"
          label="Country Name"
        />
        <div className="text-center">
          <Button name="Update" type="submit" className="btn btn-warning" />
        </div>
      </form>
      <ToastContainer />
    </div>
  );
};

export default Update;
