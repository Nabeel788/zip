import React, { useState } from "react";
import axios from "axios";
import "react-toastify/dist/ReactToastify.css";
import { ToastContainer, toast } from "react-toastify";
import Input from "../../../common/Input";
import Button from "../../../common/Button";
import TextArea from "../../../common/TextArea";

const Add = () => {
  const [title, setTitle] = useState("");
  const [year, setYear] = useState(0);
  const [description, setDescription] = useState("");
  const [image, setImage] = useState(null);
  const [fileSizeError, setFileSizeError] = useState(false);

  // error messages
  const created = "Created Successfully";
  const errorMessage = "something Bad Happend";
  const titleError = "Title is missing";
  const yearError = "Year is missing";
  const descriptionError = "Description is missing";
  const imageError = "image is missing";
  const imageSizeError = "Please choose file less than 5 MB";

  const notifyCreate = (message) => toast.success(message);
  const notifyError = (message) => toast.error(message);

  const handleImageChange = (e) => {
    const selectedFile = e.target.files[0];

    if (selectedFile && selectedFile.size > 5 * 1024 * 1024) {
      setFileSizeError(true);
      try {
        notifyError(imageSizeError);
      } catch (error) {
        console.log(error);
      }
    } else {
      setFileSizeError(false);
      setImage(selectedFile);
    }
  };

  const handleTitleChange = (e) => {
    setTitle(e.target.value);
  };

  const handleYearChange = (e) => {
    setYear(e.target.value);
  };

  const handleDescriptionChange = (e) => {
    setDescription(e.target.value);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const formData = new FormData();
    formData.append("title", title);
    formData.append("year", year);
    formData.append("description", description);
    formData.append("image", image);

    if (!fileSizeError) {
      switch (true) {
        case !title:
          notifyError(titleError);
          break;

        case !description:
          notifyError(descriptionError);
          break;

        case !year:
          notifyError(yearError);
          break;

        case !image:
          notifyError(imageError);
          break;

        default:
          try {
            // send a POST request to the server to add the item
            const response = await axios.post(
              "/api/about/history-work/add",
              formData
            );
            notifyCreate(created);
            // handle the response and perform any necessary actions
            console.log(response);
            console.log(response.data);

            // reset the form
            setTitle("");
            setYear(0);
            setDescription("");
          } catch (error) {
            notifyError(errorMessage);
            console.error(error);
          }
          break;
      }
    }
  };

  return (
    <div>
      <h3 className="text-center">Add History Work</h3>
      <form onSubmit={handleSubmit}>
        <Input
          onChange={handleTitleChange}
          id="floatingInputTitle"
          placeholder="Title"
          label="Title"
        />
        <Input
          value={year}
          onChange={handleYearChange}
          id="floatingInputYear"
          placeholder="YYYY"
          label="Please enter a 4-digit year"
          maxLength="4"
          pattern="[0-9]{4}"
        />
        <TextArea
          name="Description"
          value={description}
          onChange={handleDescriptionChange}
          id="floatingDescription2"
          boxHeight="5rem"
        />
        <Input
          type="file"
          onChange={handleImageChange}
          id="floatingInputImage"
          placeholder="Image"
          label="Image - Please select file less than 5 MB - 569x338"
        />
        <div className="text-center">
          <Button name="Submit" type="submit" className="btn btn-primary" />
        </div>
      </form>
      <ToastContainer />
    </div>
  );
};

export default Add;
