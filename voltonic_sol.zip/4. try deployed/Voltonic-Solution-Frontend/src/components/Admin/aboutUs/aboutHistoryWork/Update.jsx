import React, { useEffect, useState } from "react";
import axios from "axios";
import { Link, useParams } from "react-router-dom";
import { ToastContainer, toast } from "react-toastify";
import TextArea from "../../../common/TextArea";
import Input from "../../../common/Input";
import Button from "../../../common/Button";

const Update = () => {
  const [title, setTitle] = useState("");
  const [year, setYear] = useState(0);
  const [description, setDescription] = useState("");
  const [image, setImage] = useState(null);
  const [existingImage, setExistingImage] = useState("");
  const [fileSizeError, setFileSizeError] = useState(false);
  const { id } = useParams();

  // error messages
  const created = "Created Successfully";
  const errorMessage = "something Bad Happend";
  const titleError = "Title is missing";
  const yearError = "Year is missing";
  const descriptionError = "Description is missing";
  const imageError = "image is missing";
  const imageSizeError = "Please choose file less than 5 MB";

  const notifyCreate = (message) => toast.success(message);
  const notifyError = (message) => toast.error(message);

  useEffect(() => {
    const loadItems = async () => {
      try {
        const response = await axios.get(
          `/api/about/history-work/get-single-item/${id}`
        );
        const itemData = response.data;

        console.log(itemData);
        setTitle(itemData.title);
        setYear(itemData.year);
        setDescription(itemData.description);
        setExistingImage(`/uploads/${itemData.image}`);
      } catch (error) {
        console.log(error);
      }
    };
    loadItems();
  }, [id]);

  const handleImageChange = (e) => {
    const selectedFile = e.target.files[0];

    if (selectedFile) {
      if (selectedFile.size > 5 * 1024 * 1024) {
        setFileSizeError(true);
        try {
          notifyError(imageSizeError);
        } catch (error) {
          console.log(error);
        }
      } else {
        setFileSizeError(false);
        setImage(selectedFile || existingImage);
      }
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const formData = new FormData();
    formData.append("title", title);
    formData.append("year", year);
    formData.append("description", description);
    formData.append("image", image || existingImage);

    if (!fileSizeError) {
      switch (true) {
        case !title:
          notifyError(titleError);
          break;

        case !year:
          notifyError(yearError);
          break;

        case !description:
          notifyError(descriptionError);
          break;

        default:
          try {
            // send a POST request to the server to add the product
            const response = await axios.post(
              `/api/about/history-work/update/${id}`,
              formData
            );
            notifyCreate(created);
            // handle the response and perform any necessary actions
            console.log(response);
            console.log(response.data);

            // reset the form
          } catch (error) {
            notifyError(errorMessage);
            console.error(error);
          }
          break;
      }
    }
  };

  return (
    <div>
      <h3 className="text-center">Update History Work</h3>
      <form onSubmit={handleSubmit}>
        <Input
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          id="floatingInputTitle"
          placeholder="Title"
          label="Title"
        />
        <Input
          value={year}
          onChange={(e) => setYear(e.target.value)}
          id="floatingInputYear"
          placeholder="YYYY"
          label="Please enter a 4-digit year"
          maxLength="4"
          pattern="[0-9]{4}"
        />
        <TextArea
          name="Description"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          id="floatingDescription2"
          boxHeight="5rem"
        />
        <div className="d-flex">
          {existingImage && (
            <img
              src={existingImage}
              alt={existingImage}
              className="img-fluid mb-2 col-1"
            />
          )}
          {
            <Input
              type="file"
              onChange={handleImageChange}
              id="floatingInputImage"
              placeholder="Image"
              label="Image - Please select file less than 5MB - 569x338"
              name={existingImage}
              defaultValue={existingImage}
            />
          }
        </div>
        <div className="text-center">
          <Button name="Update" type="submit" className="btn btn-warning" />
        </div>
      </form>
      <ToastContainer />
    </div>
  );
};

export default Update;
