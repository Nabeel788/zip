import React, { useEffect, useState } from "react";
import axios from "axios";
import { Link, useParams } from "react-router-dom";
import { ToastContainer, toast } from "react-toastify";
import TextArea from "../../../common/TextArea";
import Input from "../../../common/Input";
import Button from "../../../common/Button";
import IconsList from "../../../common/IconsList";

const Update = () => {
  const [heading, setHeading] = useState("");
  const [description, setDescription] = useState("");
  const [iconClass, setIconClass] = useState("");
  const { id } = useParams();

  // error messages
  const created = "Created Successfully";
  const iconCopied = "Copied";
  const errorMessage = "something Bad Happend";
  const descriptionError = "Description is missing";
  const headingError = "Heading is missing";
  const iconClassError = "icon is missing";

  const notifyCreate = (message) => toast.success(message);
  const notifyError = (message) => toast.error(message);

  useEffect(() => {
    const loadItems = async () => {
      try {
        const response = await axios.get(
          `/api/about/features/get-single-item/${id}`
        );
        const itemData = response.data;

        console.log(itemData);
        setHeading(itemData.heading);
        setDescription(itemData.description);
        setIconClass(itemData.iconClass);
      } catch (error) {
        console.log(error);
      }
    };
    loadItems();
  }, [id]);

  const handleHeadingChange = (e) => {
    setHeading(e.target.value);
  };

  const handleIconChange = (e) => {
    setIconClass(e.target.value);
  };

  const handleDescriptionChange = (e) => {
    setDescription(e.target.value);
  };

  const handleCopyClick = (text) => {
    navigator.clipboard
      .writeText(text)
      .then(() => {
        // successful copy
        notifyCreate(iconCopied);
      })
      .catch((error) => {
        console.log(error);
      });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    switch (true) {
      case !heading:
        notifyError(headingError);
        break;

      case !iconClass:
        notifyError(iconClassError);
        break;

      case !description:
        notifyError(descriptionError);
        break;

      default:
        try {
          // send a POST request to the server to add the product
          const response = await axios.post(
            `/api/about/features/update/${id}`,
            {
              heading,
              iconClass,
              description,
            }
          );
          notifyCreate(created);
          // handle the response and perform any necessary actions
          console.log(response);
          console.log(response.data);

          // reset the form
        } catch (error) {
          notifyError(errorMessage);
          console.error(error);
        }
        break;
    }
  };

  return (
    <div>
      <h3 className="text-center">Update Feature</h3>
      <form onSubmit={handleSubmit}>
        <Input
          value={heading}
          onChange={handleHeadingChange}
          id="floatingInputHeading"
          placeholder="Heading"
          label="Heading"
        />
        <Input
          value={iconClass}
          onChange={handleIconChange}
          id="floatingInputIcon"
          placeholder="Use theme Icon class names only i.e. industrio-icon-innovation"
          label="Icon Class Name"
        />
        <TextArea
          name="Description"
          value={description}
          onChange={handleDescriptionChange}
          id="floatingDescription2"
        />
        <div className="text-center">
          <Button name="Update" type="submit" className="btn btn-warning" />
        </div>
      </form>
      <IconsList handleCopyClick={handleCopyClick} />
      <ToastContainer />
    </div>
  );
};

export default Update;
