import React, { useState } from "react";
import axios from "axios";
import "react-toastify/dist/ReactToastify.css";
import { ToastContainer, toast } from "react-toastify";
import Input from "../../../common/Input";
import Button from "../../../common/Button";
import IconsList from "../../../common/IconsList";

const Add = () => {
  const [heading, setHeading] = useState("");
  const [url, setUrl] = useState("");
  const [serviceName, setServiceName] = useState("");
  const [iconClass, setIconClass] = useState("");
  const [image, setImage] = useState(null);
  const [fileSizeError, setFileSizeError] = useState(false);

  // error messages
  const created = "Created Successfully";
  const errorMessage = "something Bad Happend";
  const serviceNameError = "Service Name is missing";
  const headingError = "Heading is missing";
  const imageError = "image is missing";
  const imageSizeError = "Please choose file less than 5 MB";
  const iconCopied = "Copied";
  const iconClassError = "icon is missing";
  const urlError = "url is missing";

  const notifyCreate = (message) => toast.success(message);
  const notifyError = (message) => toast.error(message);

  const handleImageChange = (e) => {
    const selectedFile = e.target.files[0];

    if (selectedFile && selectedFile.size > 5 * 1024 * 1024) {
      setFileSizeError(true);
      try {
        notifyError(imageSizeError);
      } catch (error) {
        console.log(error);
      }
    } else {
      setFileSizeError(false);
      setImage(selectedFile);
    }
  };

  const handleServiceNameChange = (e) => {
    setServiceName(e.target.value);
  };

  const handleHeadingChange = (e) => {
    setHeading(e.target.value);
  };

  const handleUrlChange = (e) => {
    setUrl(e.target.value);
  };

  const handleIconChange = (e) => {
    setIconClass(e.target.value);
  };

  const handleCopyClick = (text) => {
    navigator.clipboard
      .writeText(text)
      .then(() => {
        // successful copy
        notifyCreate(iconCopied);
      })
      .catch((error) => {
        console.log(error);
      });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const formData = new FormData();
    formData.append("heading", heading);
    formData.append("serviceName", serviceName);
    formData.append("iconClass", iconClass);
    formData.append("url", url);
    formData.append("image", image);

    if (!fileSizeError) {
      switch (true) {
        case !heading:
          notifyError(headingError);
          break;

        case !url:
          notifyError(urlError);
          break;

        case !iconClass:
          notifyError(iconClassError);
          break;

        case !serviceName:
          notifyError(serviceNameError);
          break;

        case !image:
          notifyError(imageError);
          break;

        default:
          try {
            // send a POST request to the server to add the product
            const response = await axios.post(
              "/api/about/choose-service/add",
              formData
            );
            notifyCreate(created);
            // handle the response and perform any necessary actions
            console.log(response);
            console.log(response.data);

            // reset the form
            setServiceName("");
            setHeading("");
            setIconClass("");
            setUrl("");
          } catch (error) {
            notifyError(errorMessage);
            console.error(error);
          }
          break;
      }
    }
  };

  return (
    <div>
      <h3 className="text-center">Add Choose - Service</h3>
      <form onSubmit={handleSubmit}>
        <Input
          value={heading}
          onChange={handleHeadingChange}
          id="floatingInputHeading"
          placeholder="Heading"
          label="Heading"
        />
        <Input
          value={serviceName}
          onChange={handleServiceNameChange}
          id="floatingInputServiceName"
          placeholder="ServiceName"
          label="ServiceName"
        />
        <Input
          value={url}
          onChange={handleUrlChange}
          id="floatingInputUrl"
          placeholder="Url"
          label="Url"
        />
        <Input
          value={iconClass}
          onChange={handleIconChange}
          id="floatingInputIcon"
          placeholder="Use theme Icon class names only i.e. industrio-icon-innovation"
          label="Icon Class Name"
        />
        <Input
          type="file"
          onChange={handleImageChange}
          id="floatingInputImage"
          placeholder="Image"
          label="Image - Please select file less than 5 MB - 490 x 421"
        />
        <div className="text-center">
          <Button name="Submit" type="submit" className="btn btn-primary" />
        </div>
      </form>
      <IconsList handleCopyClick={handleCopyClick} />
      <ToastContainer />
    </div>
  );
};

export default Add;
